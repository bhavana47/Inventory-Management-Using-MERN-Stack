import React, { Component } from 'react';
//import axios from 'axios';
//mport { useQuery } from 'react-query'
export default class Login extends Component {
    render()
    {
        return(
            <h1>Login</h1>
        )
    }
}